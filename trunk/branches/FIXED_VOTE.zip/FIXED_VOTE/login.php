<?php

require_once("libs/functions.php");
require_once("libs/AccountData.class.php");
require_once("libs/Captcha.class.php");

class Login
{
	function Title()
	{
		?>
        	..:: Advanced Vote-Reward System 0.4 ::.. 
		<?php
	}

	function Form()
	{
		?>

  <tr>

  </tr>
</table>
      
      <table width="90%" border="0" cellpadding="2" cellspacing="2" class="erro">
<?php
if($msg != "")
{
?>
        <tr> 
          <td height="30" colspan="2" class="erro"> 
            <?php echo $msg;?>
          </td>
        </tr>
<?php
}
?>
        <form action="" method="post">
            	<input name="login" type="hidden" />
<br />
<br /><br />
          <tr> 
            <td width="42%" height="30" align="right"> <strong>Username :</strong></td>
            <td width="58%" valign="top"> <input name="name" type="text" class="inputs" id="name" style="width:120px;" maxlength="45" value="<?php echo $_POST["name"]?>" /> 
            </td>
          </tr>

          <tr> 
            <td height="30" align="right"> <strong>Password :</strong></td>
            <td valign="top"> <input name="password" type="password" class="inputs" id="password" style="width:100px;" maxlength="65" value="<?php echo $_POST["password"]?>"/> 
            </td>
<br /><br />
          </tr>
          <tr> 


            <td >&nbsp;</td>

            <td width="60%" height="30" align="mid"><input type="image" src="img/enter_button.gif" width="50" height="20" border="0"></td>
          </tr>
        </form>
      </table>
        <?php
	}

	function Fail()
	{
		?>
 Please enter correctly your account name or/and your password !
 <script type="text/javascript">window.setTimeout("window.location=''",2000);</script>
        
        <?php
	}

	function Success()
	{
		?>
        	Successfully logged in. Please wait while we redirect you.
            <script type="text/javascript">window.setTimeout("window.location=''",2000);</script>
        <?php
	}

	function Content()
	{


 if(file_exists('install/index.php'))
	echo('<div style="font-size: 20px; background-color: #FFF; color:#000;"><strong><center><br />Warning: The install folder exists. Please delete install folder, before start AVRS on your live server.<br /><br /></center></strong></div>');
		if(isset($_POST["password"]))
{
 
                                
		$objAccountData = new AccountData();	
		$objAccountData->LoadByPost();

		if($objAccountData->FazerLogin())
		{
                                                  
			$_SESSION['id'] = $objAccountData->id;
			$_SESSION['name'] = $objAccountData->name;
			$_SESSION['access_level'] = $objAccountData->access_level;
            $_SESSION['id1'] = $objAccountData->id;
            $_SESSION['points'] = $objAccountData->reward_points;
            $_SESSION['account'] = $objAccountData->name;
            $_SESSION['authenticated']= true;
			
			$this->Success();
			return;

		}else{
			return $this->Fail();
		}



}
                  $this->Form();
	}
	
	function __construct()
	{
		include("html/main4.php");
include("footer.php");
	}
}

?>


