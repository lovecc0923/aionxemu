<?php



function cryptPassword($password)
{
	if($password != "")
		return mysql_escape_string(base64_encode(pack("H*", sha1(utf8_encode($password)))));
}


?>