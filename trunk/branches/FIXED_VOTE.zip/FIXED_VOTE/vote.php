<?php
class Vote
{
function Title()
	{
	?>Vote <?php
	}
		function GetVoteForm1()
	{
		
		$Con = mysql_connect(Gamedb_host,Gamedb_user,Gamedb_pass);
		mysql_select_db(Gamedb);
        mysql_query("DELETE FROM votes WHERE time < ".(time()-12*60*60));
		$res = mysql_query("SELECT id,name,image,url,reward_points FROM votemodules WHERE id='1'");
		while($Row = mysql_fetch_array($res))
                                     {
			$r = mysql_query("SELECT time FROM votes WHERE module='1' AND ip='{$_SERVER['REMOTE_ADDR']}'");
			if(!$R = mysql_fetch_array($r))
				$time = "You can vote now!" ;
			else
			{
				$Expiretime = (int)$R['time'] + (12*60*60);
				$Until = $Expiretime - time();
				$time = ceil($Until/60/60);
			}
			if($time == 1)
				$time = "".$time." hour remaining!";
			elseif($time > 1)
				$time =  "".$time." hours remaining!";
		?>

				<form action="?act=vote&do=vote1" target="<?php echo $Row['name']; ?>" method="post" style="width: 564px">
<table style="margin-left:30px; width: 535px;" border="0">
					<input name="module" type="hidden" value="<?php echo $Row['id']; ?>" />
					<input name="to" type="hidden" value="<?php echo $Row['url']; ?>" />
					<tr>
						<td width="10"></td>
						<td width="50" valign="top"><img src="<?php echo $Row['image']; ?>"  /></td>
						<td width="10"></td>
						<td valign="mid" align="left" style="width: 86px"><FORM METHOD="LINK" ACTION="?act=vote&do=vote1"><INPUT ALT="Click to Vote" title="Click to Vote!" TYPE="submit" name="account" VALUE="<?php echo $_SESSION['account']; ?>"></FORM></td>
					<tr>
						<td><td valign="bottom" ><b>Reward points: <b><?php echo $Row['reward_points']; ?></td><td></td>
                        <td style="width: 86px"><b><?php echo $time; ?></b>
					</tr>
					<tr>
						<td colspan="4">&nbsp;</td>
					</tr>
				</form><table>
			<?php
			
		}

                                   
		mysql_close($Con);
                               
	}

	function GetVoteForm2()
	{
		
		$Con = mysql_connect(Gamedb_host,Gamedb_user,Gamedb_pass);
		mysql_select_db(Gamedb);
        mysql_query("DELETE FROM votes WHERE time < ".(time()-12*60*60));
		$res = mysql_query("SELECT id,name,image,url,reward_points FROM votemodules WHERE id='2'");
		while($Row = mysql_fetch_array($res))
        {
			$r = mysql_query("SELECT time FROM votes WHERE module='2' AND ip='{$_SERVER['REMOTE_ADDR']}'");
			if(!$R = mysql_fetch_array($r))
				$time = "You can vote now!";
			else
			{
				$Expiretime = (int)$R['time'] + (12*60*60);
				$Until = $Expiretime - time();
				$time = ceil($Until/60/60);
			}
			if($time == 1)
				$time = "".$time." hour remaining!";
			elseif($time > 1)
				$time =  "".$time." hours remaining!";
		?>

				<form action="?act=vote&do=vote2" target="<?php echo $Row['name']; ?>" method="post">
<table style="margin-left:30px; width: 535px;" border="0"><hr>
					<input name="module" type="hidden" value="<?php echo $Row['id']; ?>" />
					<input name="to" type="hidden" value="<?php echo $Row['url']; ?>" />
					<tr>
						<td width="10"></td>
						<td width="50" valign="top"><img src="<?php echo $Row['image']; ?>"/></td>
						<td width="10"></td>
						<td valign="mid" align="left" style="width: 308px"><FORM METHOD="LINK" ACTION="?act=vote&do=vote2"><INPUT ALT="Click to Vote" title="Click to Vote!" TYPE="submit" name="account" VALUE="<?php echo $_SESSION['account']; ?>"></FORM></td>
					<tr>
						<td><td valign="bottom" ><b>Reward points: <b><?php echo $Row['reward_points']; ?></td><td></td>
                        <td style="width: 308px"><b><?php echo $time; ?></b>
					</tr>
					<tr>
						<td colspan="4">&nbsp;</td>
					</tr>
				</form><table>
			<?php
		}

                                   
		mysql_close($Con);
                               
	}
	function GetVoteForm3()
	{
		
		$Con = mysql_connect(Gamedb_host,Gamedb_user,Gamedb_pass);
		mysql_select_db(Gamedb);
		mysql_query("DELETE FROM votes WHERE time < ".(time()-12*60*60));
		$res = mysql_query("SELECT id,name,image,url,reward_points FROM votemodules WHERE id='3'");
		while($Row = mysql_fetch_array($res))
                                     {
			$r = mysql_query("SELECT time FROM votes WHERE module='3' AND ip='{$_SERVER['REMOTE_ADDR']}'");
			if(!$R = mysql_fetch_array($r))
				$time = "You can vote now!" ;
			else
			{
				$Expiretime = (int)$R['time'] + (12*60*60);
				$Until = $Expiretime - time();
				$time = ceil($Until/60/60);
			}
			if($time == 1)
				$time = "".$time." hour remaining!";
			elseif($time > 1)
				$time =  "".$time." hours remaining!";
		?>

				<form action="?act=vote&do=vote3" target="<?php echo $Row['name']; ?>" method="post">
<table style="margin-left:30px; width: 535px;" border="0"><hr>
					<input name="module" type="hidden" value="<?php echo $Row['id']; ?>" />
					<input name="to" type="hidden" value="<?php echo $Row['url']; ?>" />
					<tr>
						<td width="10"></td>
						<td width="50" valign="top"><img src="<?php echo $Row['image']; ?>" /></td>
						<td width="10"></td>
						<td width="300" valign="mid" align="left"><FORM METHOD="LINK" ACTION="?act=vote&do=vote3"><INPUT ALT="Click to Vote" title="Click to Vote!" TYPE="submit" name="account" VALUE="<?php echo $_SESSION['account']; ?>"></FORM></td>
					<tr>
						<td><td valign="bottom" ><b>Reward points: <b><?php echo $Row['reward_points']; ?></td><td></td>
                        <td><b><?php echo $time; ?></b>
					</tr>
					<tr>
						<td colspan="4">&nbsp;</td>
					</tr>
				</form><table>
				</form>
			<?php
		}

                                   
		mysql_close($Con);
                               
	}

	function GetVoteForm4()
	{
		
		$Con = mysql_connect(Gamedb_host,Gamedb_user,Gamedb_pass);
		mysql_select_db(Gamedb);
    mysql_query("DELETE FROM votes WHERE time < ".(time()-12*60*60));
		$res = mysql_query("SELECT id,name,image,url,reward_points FROM votemodules WHERE id='4'");
		while($Row = mysql_fetch_array($res))
                                     {
			$r = mysql_query("SELECT time FROM votes WHERE module='4' AND ip='{$_SERVER['REMOTE_ADDR']}'");
			if(!$R = mysql_fetch_array($r))
				$time = "You can vote now!" ;
			else
			{
				$Expiretime = (int)$R['time'] + (12*60*60);
				$Until = $Expiretime - time();
				$time = ceil($Until/60/60);
			}
			if($time == 1)
				$time = "".$time." hour remaining!";
			elseif($time > 1)
				$time =  "".$time." hours remaining!";
		?>

				<form action="?act=vote&do=vote4" target="<?php echo $Row['name']; ?>" method="post">
<table style="margin-left:30px; width: 535px;" border="0"><hr>
					<input name="module" type="hidden" value="<?php echo $Row['id']; ?>" />
					<input name="to" type="hidden" value="<?php echo $Row['url']; ?>" />
					<tr>
						<td width="10"></td>
						<td width="50" valign="top"><img src="<?php echo $Row['image']; ?>"/></td>
						<td width="10"></td>
						<td width="300" valign="mid" align="left"><FORM METHOD="LINK" ACTION="?act=vote&do=vote4"><INPUT ALT="Click to Vote" title="Click to Vote!" TYPE="submit" name="account" VALUE="<?php echo $_SESSION['account']; ?>"></FORM></td>
					<tr>
						<td><td valign="bottom" ><b>Reward points: <b><?php echo $Row['reward_points']; ?></td><td></td>
                        <td><b><?php echo $time; ?></b>
					</tr>
					<tr>
						<td colspan="4">&nbsp;</td>
					</tr>
				</form><table>
			<?php
		}

                                   
		mysql_close($Con);
                               
	}

	function GetVoteForm5()
	{
		
		$Con = mysql_connect(Gamedb_host,Gamedb_user,Gamedb_pass);
		mysql_select_db(Gamedb);
                                    mysql_query("DELETE FROM votes WHERE time < ".(time()-12*60*60));
		$res = mysql_query("SELECT id,name,image,url,reward_points FROM votemodules WHERE id='5'");
		while($Row = mysql_fetch_array($res))
                                     {
			$r = mysql_query("SELECT time FROM votes WHERE module='5' AND ip='{$_SERVER['REMOTE_ADDR']}'");
			if(!$R = mysql_fetch_array($r))
				$time = "You can vote now!" ;
			else
			{
				$Expiretime = (int)$R['time'] + (12*60*60);
				$Until = $Expiretime - time();
				$time = ceil($Until/60/60);
			}
			if($time == 1)
				$time = "".$time." hour remaining!";
			elseif($time > 1)
				$time =  "".$time." hours remaining!";
		?>

				<form action="?act=vote&do=vote5" target="<?php echo $Row['name']; ?>" method="post">
<table style="margin-left:30px; width: 535px;" border="0"><hr>
					<input name="module" type="hidden" value="<?php echo $Row['id']; ?>" />
					<input name="to" type="hidden" value="<?php echo $Row['url']; ?>" />
					<tr>
						<td width="10"></td>
						<td width="50" valign="top"><img src="<?php echo $Row['image']; ?>"/></td>
						<td width="10"></td>
						<td width="300" valign="mid" align="left"><FORM METHOD="LINK" ACTION="?act=vote&do=vote5"><INPUT ALT="Click to Vote" title="Click to Vote!" TYPE="submit" name="account" VALUE="<?php echo $_SESSION['account']; ?>"></FORM></td>
					<tr>
						<td><td valign="bottom" ><b>Reward points: <b><?php echo $Row['reward_points']; ?></td><td></td>
                        <td><b><?php echo $time; ?></b>
					</tr>
					<tr>
						<td colspan="4">&nbsp;</td>
					</tr>
				</form><table>
			<?php
		}

                                   
		mysql_close($Con);
                               
	}

	function GetVoteForm6()
	{
		$Con = mysql_connect(Gamedb_host,Gamedb_user,Gamedb_pass);
		mysql_select_db(Gamedb);
    mysql_query("DELETE FROM votes WHERE time < ".(time()-12*60*60));
		$res = mysql_query("SELECT id,name,image,url,reward_points FROM votemodules WHERE id='6'");
		while($Row = mysql_fetch_array($res))
                                     {
			$r = mysql_query("SELECT time FROM votes WHERE module='6' AND ip='{$_SERVER['REMOTE_ADDR']}'");
			if(!$R = mysql_fetch_array($r))
				$time = "You can vote now!" ;
			else
			{
				$Expiretime = (int)$R['time'] + (12*60*60);
				$Until = $Expiretime - time();
				$time = ceil($Until/60/60);
			}
			if($time == 1)
				$time = "".$time." hour remaining!";
			elseif($time > 1)
				$time =  "".$time." hours remaining!";
		?>

				<form action="?act=vote&do=vote6" target="<?php echo $Row['name']; ?>" method="post">
<table style="margin-left:30px; width: 535px;" border="0"><hr>
					<input name="module" type="hidden" value="<?php echo $Row['id']; ?>" />
					<input name="to" type="hidden" value="<?php echo $Row['url']; ?>" />
					<tr>
						<td width="10"></td>
						<td width="50" valign="top"><img src="<?php echo $Row['image']; ?>" " /></td>
						<td width="10"></td>
						<td width="300" valign="mid" align="left"><FORM METHOD="LINK" ACTION="?act=vote&do=vote6"><INPUT ALT="Click to Vote" title="Click to Vote!" TYPE="submit" name="account" VALUE="<?php echo $_SESSION['account']; ?>"></FORM></td>
					<tr>
						<td><td valign="bottom" ><b>Reward points: <b><?php echo $Row['reward_points']; ?></td><td></td>
                        <td><b><?php echo $time; ?></b>
					</tr>
					<tr>
						<td colspan="4">&nbsp;</td>
					</tr>
				</form><table>
			<?php
		}

                                   
		mysql_close($Con);
                               
	}

	function GetVoteForm7()
	{
		
		$Con = mysql_connect(Gamedb_host,Gamedb_user,Gamedb_pass);
		mysql_select_db(Gamedb);
    mysql_query("DELETE FROM votes WHERE time < ".(time()-12*60*60));
		$res = mysql_query("SELECT id,name,image,url,reward_points FROM votemodules WHERE id='7'");
		while($Row = mysql_fetch_array($res))
                                     {
			$r = mysql_query("SELECT time FROM votes WHERE module='7' AND ip='{$_SERVER['REMOTE_ADDR']}'");
			if(!$R = mysql_fetch_array($r))
				$time = "You can vote now!" ;
			else
			{
				$Expiretime = (int)$R['time'] + (12*60*60);
				$Until = $Expiretime - time();
				$time = ceil($Until/60/60);
			}
			if($time == 1)
				$time = "".$time." hour remaining!";
			elseif($time > 1)
				$time =  "".$time." hours remaining!";
		?>

				<form action="?act=vote&do=vote7" target="<?php echo $Row['name']; ?>" method="post">
<table style="margin-left:30px; width: 535px;" border="0"><hr>
					<input name="module" type="hidden" value="<?php echo $Row['id']; ?>" />
					<input name="to" type="hidden" value="<?php echo $Row['url']; ?>" />
					<tr>
						<td width="10"></td>
						<td width="50" valign="top"><img src="<?php echo $Row['image']; ?>"/></td>
						<td width="10"></td>
						<td width="300" valign="mid" align="left"><FORM METHOD="LINK" ACTION="?act=vote&do=vote7"><INPUT ALT="Click to Vote" title="Click to Vote!" TYPE="submit" name="account" VALUE="<?php echo $_SESSION['account']; ?>"></FORM></td>
					<tr>
						<td><td valign="bottom" ><b>Reward points: <b><?php echo $Row['reward_points']; ?></td><td></td>
                        <td><b><?php echo $time; ?></b>
					</tr>
					<tr>
						<td colspan="4">&nbsp;</td>
					</tr>
				</form><table>
			<?php
		}

                                   
		mysql_close($Con);
                               
	}

	function GetVoteForm8()
	{
		
		$Con = mysql_connect(Gamedb_host,Gamedb_user,Gamedb_pass);
		mysql_select_db(Gamedb);
    mysql_query("DELETE FROM votes WHERE time < ".(time()-12*60*60));
		$res = mysql_query("SELECT id,name,image,url,reward_points FROM votemodules WHERE id='8'");
		while($Row = mysql_fetch_array($res))
                                     {
			$r = mysql_query("SELECT time FROM votes WHERE module='8' AND ip='{$_SERVER['REMOTE_ADDR']}'");
			if(!$R = mysql_fetch_array($r))
				$time = "You can vote now!" ;
			else
			{
				$Expiretime = (int)$R['time'] + (12*60*60);
				$Until = $Expiretime - time();
				$time = ceil($Until/60/60);
			}
			if($time == 1)
				$time = "".$time." hour remaining!";
			elseif($time > 1)
				$time =  "".$time." hours remaining!";
		?>

				<form action="?act=vote&do=vote8" target="<?php echo $Row['name']; ?>" method="post">
<table style="margin-left:30px; width: 535px;" border="0"><hr>
					<input name="module" type="hidden" value="<?php echo $Row['id']; ?>" />
					<input name="to" type="hidden" value="<?php echo $Row['url']; ?>" />
					<tr>
						<td width="10"></td>
						<td width="50" valign="top"><img src="<?php echo $Row['image']; ?>"/></td>
						<td width="10"></td>
						<td width="300" valign="mid" align="left"><FORM METHOD="LINK" ACTION="?act=vote&do=vote8"><INPUT ALT="Click to Vote" title="Click to Vote!" TYPE="submit" name="account" VALUE="<?php echo $_SESSION['account']; ?>"></FORM></td>
					<tr>
						<td><td valign="bottom" ><b>Reward points: <b><?php echo $Row['reward_points']; ?></td><td></td>
                        <td><b><?php echo $time; ?></b>
					</tr>
					<tr>
						<td colspan="4">&nbsp;</td>
					</tr>
				</form><table>
			<?php
		}

                                   
		mysql_close($Con);
                               
	}

		function GetVoteForm9()
	{
		
		$Con = mysql_connect(Gamedb_host,Gamedb_user,Gamedb_pass);
		mysql_select_db(Gamedb);
    mysql_query("DELETE FROM votes WHERE time < ".(time()-12*60*60));
		$res = mysql_query("SELECT id,name,image,url,reward_points FROM votemodules WHERE id='9'");
		while($Row = mysql_fetch_array($res))
                                     {
			$r = mysql_query("SELECT time FROM votes WHERE module='9' AND ip='{$_SERVER['REMOTE_ADDR']}'");
			if(!$R = mysql_fetch_array($r))
				$time = "You can vote now!" ;
			else
			{
				$Expiretime = (int)$R['time'] + (12*60*60);
				$Until = $Expiretime - time();
				$time = ceil($Until/60/60);
			}
			if($time == 1)
				$time = "".$time." hour remaining!";
			elseif($time > 1)
				$time =  "".$time." hours remaining!";
		?>

				<form action="?act=vote&do=vote9" target="<?php echo $Row['name']; ?>" method="post">
<table style="margin-left:30px; width: 535px;" border="0"><hr>
					<input name="module" type="hidden" value="<?php echo $Row['id']; ?>" />
					<input name="to" type="hidden" value="<?php echo $Row['url']; ?>" />
					<tr>
						<td width="10"></td>
						<td width="50" valign="top"><img src="<?php echo $Row['image']; ?>"  /></td>
						<td width="10"></td>
						<td width="300" valign="mid" align="left"><FORM METHOD="LINK" ACTION="?act=vote&do=vote9"><INPUT ALT="Click to Vote" title="Click to Vote!" TYPE="submit" name="account" VALUE="<?php echo $_SESSION['account']; ?>"></FORM></td>
					<tr>
						<td><td valign="bottom" ><b>Reward points: <b><?php echo $Row['reward_points']; ?></td><td></td>
                        <td><b><?php echo $time; ?></b>
					</tr>
					<tr>
						<td colspan="4">&nbsp;</td>
					</tr>
				</form><table>
			<?php
		}

                                   
		mysql_close($Con);
                               
	}


	function Form()
	{
		?>
			<table style="margin-left:0px;" border="0" width="510">
				<tr>
					
					
				</tr>
				<?php $this->GetVoteForm1(); ?>
				<?php $this->GetVoteForm2(); ?>
				<?php $this->GetVoteForm3(); ?>
			  <?php $this->GetVoteForm4(); ?>
				<?php $this->GetVoteForm5(); ?>
				<?php $this->GetVoteForm6(); ?>
				<?php $this->GetVoteForm7(); ?>
				<?php $this->GetVoteForm8(); ?>
				<?php $this->GetVoteForm9(); ?>
			</table>
		<?php
	}
	
	function TallyVote1()
	{
		$Module = addslashes($_POST['module']);
		$Account = addslashes($_POST['account']);
		$To = addslashes($_POST['to']);
		$Ip = $_SERVER['REMOTE_ADDR'];
		
		
		$Con = mysql_connect(Gamedb_host,Gamedb_user,Gamedb_pass);
		mysql_select_db(Gamedb);
		
		//redirect
		header("Location: {$To}\r\n");
		
		//check that the module exists
		if(mysql_result(mysql_query("SELECT COUNT(*) FROM votemodules WHERE id='{$Module}'"),0) != 1)
			return;
			
		//check if the user or account has been accredited for a vote within the last 12 hrs.
		if(mysql_result(mysql_query("SELECT COUNT(*) FROM votes WHERE module='{$Module}' AND (ip = '{$Ip}' OR account = '{$Account}')"),0) != 0)
			return;
		
		//set cookie
		setcookie("vote_time","1",time()+12*60*60,"/");
		
		//add vote to timeout
		mysql_query("INSERT INTO votes VALUES ('{$Ip}','{$Account}','{$Module}','".time()."')");
		
		mysql_close($Con);
		$Con = mysql_connect(Logindb_host,Logindb_user,Logindb_pass);
		mysql_select_db(Logindb);
		
		// +1 vote point
		if($_SESSION['account'] == $Account)
		{
			(int)$_SESSION['points']+= RPPV1;
		}
		mysql_query("UPDATE account_data SET reward_points = reward_points + ".RPPV1." WHERE name='{$Account}'");
		mysql_close($Con);
	}

function TallyVote2()
	{
		$Module = addslashes($_POST['module']);
		$Account = addslashes($_POST['account']);
		$To = addslashes($_POST['to']);
		$Ip = $_SERVER['REMOTE_ADDR'];
		
		
		$Con = mysql_connect(Gamedb_host,Gamedb_user,Gamedb_pass);
		mysql_select_db(Gamedb);
		
		//redirect
		header("Location: {$To}\r\n");
		
		//check that the module exists
		if(mysql_result(mysql_query("SELECT COUNT(*) FROM votemodules WHERE id='{$Module}'"),0) != 1)
			return;
			
		//check if the user or account has been accredited for a vote within the last 12 hrs.
		if(mysql_result(mysql_query("SELECT COUNT(*) FROM votes WHERE module='{$Module}' AND (ip = '{$Ip}' OR account = '{$Account}')"),0) != 0)

			return;
		
		//set cookie
		setcookie("vote_time","1",time()+12*60*60,"/");
		
		//add vote to timeout
		mysql_query("INSERT INTO votes VALUES ('{$Ip}','{$Account}','{$Module}','".time()."')");
		
		mysql_close($Con);
		$Con = mysql_connect(Logindb_host,Logindb_user,Logindb_pass);
		mysql_select_db(Logindb);
		
		// +1 vote point
		if($_SESSION['account'] == $Account)
		{
			(int)$_SESSION['points']+= RPPV2;
		}
		mysql_query("UPDATE account_data SET reward_points = reward_points + ".RPPV2." WHERE name='{$Account}'");
		mysql_close($Con);
	}

function TallyVote3()
	{
		$Module = addslashes($_POST['module']);
		$Account = addslashes($_POST['account']);
		$To = addslashes($_POST['to']);
		$Ip = $_SERVER['REMOTE_ADDR'];
		
		
		$Con = mysql_connect(Gamedb_host,Gamedb_user,Gamedb_pass);
		mysql_select_db(Gamedb);
		
		//redirect
		header("Location: {$To}\r\n");
		
		//check that the module exists
		if(mysql_result(mysql_query("SELECT COUNT(*) FROM votemodules WHERE id='{$Module}'"),0) != 1)
			return;
			
		//check if the user or account has been accredited for a vote within the last 12 hrs.
		if(mysql_result(mysql_query("SELECT COUNT(*) FROM votes WHERE module='{$Module}' AND (ip = '{$Ip}' OR account = '{$Account}')"),0) != 0)
			return;
		
		//set cookie
		setcookie("vote_time","1",time()+12*60*60,"/");
		
		//add vote to timeout
		mysql_query("INSERT INTO votes VALUES ('{$Ip}','{$Account}','{$Module}','".time()."')");
		
		mysql_close($Con);
		$Con = mysql_connect(Logindb_host,Logindb_user,Logindb_pass);
		mysql_select_db(Logindb);
		
		// +1 vote point
		if($_SESSION['account'] == $Account)
		{
			(int)$_SESSION['points']+= RPPV3;
		}
		mysql_query("UPDATE account_data SET reward_points = reward_points + ".RPPV3." WHERE name='{$Account}'");
		mysql_close($Con);
	}

function TallyVote4()
	{
		$Module = addslashes($_POST['module']);
		$Account = addslashes($_POST['account']);
		$To = addslashes($_POST['to']);
		$Ip = $_SERVER['REMOTE_ADDR'];
		
		
		$Con = mysql_connect(Gamedb_host,Gamedb_user,Gamedb_pass);
		mysql_select_db(Gamedb);
		
		//redirect
		header("Location: {$To}\r\n");
		
		//check that the module exists
		if(mysql_result(mysql_query("SELECT COUNT(*) FROM votemodules WHERE id='{$Module}'"),0) != 1)
			return;
			
		//check if the user or account has been accredited for a vote within the last 12 hrs.
		if(mysql_result(mysql_query("SELECT COUNT(*) FROM votes WHERE module='{$Module}' AND (ip = '{$Ip}' OR account = '{$Account}')"),0) != 0)
			return;
		
		//set cookie
		setcookie("vote_time","1",time()+12*60*60,"/");
		
		//add vote to timeout
		mysql_query("INSERT INTO votes VALUES ('{$Ip}','{$Account}','{$Module}','".time()."')");
		
		mysql_close($Con);
		$Con = mysql_connect(Logindb_host,Logindb_user,Logindb_pass);
		mysql_select_db(Logindb);
		
		// +1 vote point
		if($_SESSION['account'] == $Account)
		{
			(int)$_SESSION['points']+= RPPV4;
		}
		mysql_query("UPDATE account_data SET reward_points = reward_points + ".RPPV4." WHERE name='{$Account}'");
		mysql_close($Con);
	}

function TallyVote5()
	{
		$Module = addslashes($_POST['module']);
		$Account = addslashes($_POST['account']);
		$To = addslashes($_POST['to']);
		$Ip = $_SERVER['REMOTE_ADDR'];
		
		
		$Con = mysql_connect(Gamedb_host,Gamedb_user,Gamedb_pass);
		mysql_select_db(Gamedb);
		
		//redirect
		header("Location: {$To}\r\n");
		
		//check that the module exists
		if(mysql_result(mysql_query("SELECT COUNT(*) FROM votemodules WHERE id='{$Module}'"),0) != 1)
			return;
			
		//check if the user or account has been accredited for a vote within the last 12 hrs.
		if(mysql_result(mysql_query("SELECT COUNT(*) FROM votes WHERE module='{$Module}' AND (ip = '{$Ip}' OR account = '{$Account}')"),0) != 0)
			return;
		
		//set cookie
		setcookie("vote_time","1",time()+12*60*60,"/");
		
		//add vote to timeout
		mysql_query("INSERT INTO votes VALUES ('{$Ip}','{$Account}','{$Module}','".time()."')");
		
		mysql_close($Con);
		$Con = mysql_connect(Logindb_host,Logindb_user,Logindb_pass);
		mysql_select_db(Logindb);
		
		// +1 vote point
		if($_SESSION['account'] == $Account)
		{
			(int)$_SESSION['points']+= RPPV5;
		}
		mysql_query("UPDATE account_data SET reward_points = reward_points + ".RPPV5." WHERE name='{$Account}'");
		mysql_close($Con);
	}

function TallyVote6()
	{
		$Module = addslashes($_POST['module']);
		$Account = addslashes($_POST['account']);
		$To = addslashes($_POST['to']);
		$Ip = $_SERVER['REMOTE_ADDR'];
		
		$Con = mysql_connect(Gamedb_host,Gamedb_user,Gamedb_pass);
		mysql_select_db(Gamedb);
		
		//redirect
		header("Location: {$To}\r\n");
		
		//check that the module exists
		if(mysql_result(mysql_query("SELECT COUNT(*) FROM votemodules WHERE id='{$Module}'"),0) != 1)
			return;
			
		//check if the user or account has been accredited for a vote within the last 12 hrs.
		if(mysql_result(mysql_query("SELECT COUNT(*) FROM votes WHERE module='{$Module}' AND (ip = '{$Ip}' OR account = '{$Account}')"),0) != 0)
			return;
		
		//set cookie
	//	setcookie("vote_time","1",time()+12*60*60,"/");
		setcookie("vote_time","1",time()+12*60*60,"/");
		
		//add vote to timeout
		mysql_query("INSERT INTO votes VALUES ('{$Ip}','{$Account}','{$Module}','".time()."')");
		
		mysql_close($Con);
		$Con = mysql_connect(Logindb_host,Logindb_user,Logindb_pass);
		mysql_select_db(Logindb);
		
		// +1 vote point
		if($_SESSION['account'] == $Account)
		{
			(int)$_SESSION['points']+= RPPV6;
		}
		mysql_query("UPDATE account_data SET reward_points = reward_points + ".RPPV6." WHERE name='{$Account}'");
		mysql_close($Con);
	}

function TallyVote7()
	{
		$Module = addslashes($_POST['module']);
		$Account = addslashes($_POST['account']);
		$To = addslashes($_POST['to']);
		$Ip = $_SERVER['REMOTE_ADDR'];
		
		
		$Con = mysql_connect(Gamedb_host,Gamedb_user,Gamedb_pass);
		mysql_select_db(Gamedb);
		
		//redirect
		header("Location: {$To}\r\n");
		
		//check that the module exists
		if(mysql_result(mysql_query("SELECT COUNT(*) FROM votemodules WHERE id='{$Module}'"),0) != 1)
			return;
			
		//check if the user or account has been accredited for a vote within the last 12 hrs.
		if(mysql_result(mysql_query("SELECT COUNT(*) FROM votes WHERE module='{$Module}' AND (ip = '{$Ip}' OR account = '{$Account}')"),0) != 0)
			return;
		
		//set cookie
		setcookie("vote_time","1",time()+12*60*60,"/");
		
		//add vote to timeout
		mysql_query("INSERT INTO votes VALUES ('{$Ip}','{$Account}','{$Module}','".time()."')");
		
		mysql_close($Con);
		$Con = mysql_connect(Logindb_host,Logindb_user,Logindb_pass);
		mysql_select_db(Logindb);
		
		// +1 vote point
		if($_SESSION['account'] == $Account)
		{
			(int)$_SESSION['points']+= RPPV7;
		}
		mysql_query("UPDATE account_data SET reward_points = reward_points + ".RPPV7." WHERE name='{$Account}'");
		mysql_close($Con);
	}

function TallyVote8()
	{
		$Module = addslashes($_POST['module']);
		$Account = addslashes($_POST['account']);
		$To = addslashes($_POST['to']);
		$Ip = $_SERVER['REMOTE_ADDR'];
		
		
		$Con = mysql_connect(Gamedb_host,Gamedb_user,Gamedb_pass);
		mysql_select_db(Gamedb);
		
		//redirect
		header("Location: {$To}\r\n");
		
		//check that the module exists
		if(mysql_result(mysql_query("SELECT COUNT(*) FROM votemodules WHERE id='{$Module}'"),0) != 1)
			return;
			
		//check if the user or account has been accredited for a vote within the last 12 hrs.
		if(mysql_result(mysql_query("SELECT COUNT(*) FROM votes WHERE module='{$Module}' AND (ip = '{$Ip}' OR account = '{$Account}')"),0) != 0)
			return;
		
		//set cookie
		setcookie("vote_time","1",time()+12*60*60,"/");
		
		//add vote to timeout
		mysql_query("INSERT INTO votes VALUES ('{$Ip}','{$Account}','{$Module}','".time()."')");
		
		mysql_close($Con);
		$Con = mysql_connect(Logindb_host,Logindb_user,Logindb_pass);
		mysql_select_db(Logindb);
		
		// +1 vote point
		if($_SESSION['account'] == $Account)
		{
			(int)$_SESSION['points']+= RPPV8;
		}
		mysql_query("UPDATE account_data SET reward_points = reward_points + ".RPPV8." WHERE name='{$Account}'");
		mysql_close($Con);
	}

function TallyVote9()
	{
		$Module = addslashes($_POST['module']);
		$Account = addslashes($_POST['account']);
		$To = addslashes($_POST['to']);
		$Ip = $_SERVER['REMOTE_ADDR'];
		
		
		$Con = mysql_connect(Gamedb_host,Gamedb_user,Gamedb_pass);
		mysql_select_db(Gamedb);
		
		//redirect
		header("Location: {$To}\r\n");
		
		//check that the module exists
		if(mysql_result(mysql_query("SELECT COUNT(*) FROM votemodules WHERE id='{$Module}'"),0) != 1)
			return;
			
		//check if the user or account has been accredited for a vote within the last 12 hrs.
		if(mysql_result(mysql_query("SELECT COUNT(*) FROM votes WHERE module='{$Module}' AND (ip = '{$Ip}' OR account = '{$Account}')"),0) != 0)
			return;
		
		//set cookie
		setcookie("vote_time","1",time()+12*60*60,"/");
		
		//add vote to timeout
		mysql_query("INSERT INTO votes VALUES ('{$Ip}','{$Account}','{$Module}','".time()."')");
		
		mysql_close($Con);
		$Con = mysql_connect(Logindb_host,Logindb_user,Logindb_pass);
		mysql_select_db(Logindb);
		
		// +1 vote point
		if($_SESSION['account'] == $Account)
		{
			(int)$_SESSION['points']+= RPPV9;
		}
		mysql_query("UPDATE account_data SET reward_points = reward_points + ".RPPV9." WHERE name='{$Account}'");
		mysql_close($Con);
	}
	
	function Content()
	{
		$this->Form();
	}

	function __construct()
	{
		if($_GET['do'] == "vote1")
		{
			$this->TallyVote1();
			return;
		}
if($_GET['do'] == "vote2")
		{
			$this->TallyVote2();
			return;
		}
if($_GET['do'] == "vote3")
		{
			$this->TallyVote3();
			return;
		}
if($_GET['do'] == "vote4")
		{
			$this->TallyVote4();
			return;
		}
if($_GET['do'] == "vote5")
		{
			$this->TallyVote5();
			return;
		}
if($_GET['do'] == "vote6")
		{
			$this->TallyVote6();
			return;
		}
if($_GET['do'] == "vote7")
		{
			$this->TallyVote7();
			return;
		}
if($_GET['do'] == "vote8")
		{
			$this->TallyVote8();
			return;
		}
if($_GET['do'] == "vote9")
		{
			$this->TallyVote9();
			return;
		}
                                 
		include("html/main3.php");
	}

}

?>