<?php

require_once("libs/functions.php");
require_once("libs/AccountData.class.php");
require_once("libs/Captcha.class.php");

class Chg_pwd
{
	function Title()
	{
		?>
        	Change password
		<?php
	}

	function Form()
	{
		?>

  <tr>

  </tr>
</table>
      
      <table width="200%" border="0" cellpadding="2" cellspacing="2" class="erro">

      
        <form action="" method="post">
            	<input name="chng_pwd" type="hidden" />
<br /><br /><br /><br />
          <tr> 
            <td width="42%" height="30" align="right"> <strong>Current password :</strong></td>
            <td width="58%" valign="top"> <input name="old_password" type="password" class="inputs" id="old_password" style="width:100px;" maxlength="65" /> 
            </td>
          </tr>
          <tr> 
            <td height="30" align="right"> <strong>New password :</strong></td>
            <td valign="top"> <input name="password2" type="password" class="inputs" id="password2" style="width:100px;" maxlength="65"/> 
            </td>
          </tr>
          <tr> 
            <td height="30" align="right"> <strong>New password again :</strong></td>
            <td valign="top"> <input name="password" type="password" class="inputs" id="password" style="width:100px;" maxlength="65"/> 
            </td>
          </tr>
          <tr> 
            <td >&nbsp;</td>
            <td><input type="image" src="img/bt_enviar.gif" width="46" height="14" border="0"></td>
          </tr>
        </form>
      </table>
        <?php
	}

	

	function Content()
	{
		

if($_SESSION["access_level"] == "")
{
	echo "<script>location.href='index.php'</script>";
	exit;
}


if(count($_POST) > 2)
{
	$msg = "<font color=red>".LG_ERROR_OCCURRED."</font>";

	$objAccountData = new AccountData();	

	$objAccountData->id = $_SESSION["id"];
	$objAccountData->password = cryptPassword($_POST["old_password"]);

	if($objAccountData->isPassword())
	{
		$objAccountData->password = cryptPassword($_POST["password"]);
		
		if($objAccountData->Update())
		{
			$msg = "<font color=green>Password Changed!</font>";
                                                      echo "<script>location.href='index.php'</script>";
		}
	}else{
		$msg = "<font color=red>The confirmation of the new password doesnt match</font>";
	}
}







                  $this->Form();
	}
	
	function __construct()
	{
		include("html/main3.php");

	}
}

?>


