
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>--Edit Categories in Redeem Page--</title>
<link href="../style.css" rel="stylesheet" type="text/css" />
</head>
<!-- Prepare to enter... DIV HELL!!!! -->
<body>
	<div id="topBar"></div>
	<div id="page">
		<div id="page_header">
			<div><div></div></div>
		</div>
		<div id="page_content">
			<div id="page_content_wrapper">
				<div id="page_content_content">
					<div id="page_content_padding">
						<div id="header_bar">
							<div>
								<div><table style="margin-left:130px; height:38px; vertical-align:middle;"><tr><td>--Edit Categories in Redeem Page--</td></tr></table></span>								</div>
							</div>
						</div><br />
						<div id="article">
							<style type="text/css">
	

hr.pme-hr		     { border: 0px solid; padding: 0px; margin: 0px; border-top-width: 1px; height: 1px; }
	table.pme-main 	     { border: #004d9c 1px solid; border-collapse: collapse; border-spacing: 0px; width: 100%; }
	table.pme-navigation { border: #004d9c 0px solid; border-collapse: collapse; border-spacing: 0px; width: 100%; }
	td.pme-navigation-0, td.pme-navigation-1 { white-space: nowrap; }
	th.pme-header	     { border: #004d9c 1px solid; padding: 4px; background: #add8e6; }
	td.pme-key-0, td.pme-value-0, td.pme-help-0, td.pme-navigation-0, td.pme-cell-0,
	td.pme-key-1, td.pme-value-1, td.pme-help-0, td.pme-navigation-1, td.pme-cell-1,
	td.pme-sortinfo, td.pme-filter { border: #004d9c 1px solid; padding: 3px; }
	td.pme-buttons { text-align: left;   }
	td.pme-message { text-align: center; }
	td.pme-stats   { text-align: right;  }
</style>


<?php
ob_start();
include("../index.php");
ob_end_clean();

if($_SESSION["access_level"] < 2)
{
	echo "<script>location.href='../index.php'</script>";
	exit;
}

$opts['hn'] = Gamedb_host;

$opts['un'] = Gamedb_user;

$opts['pw'] = Gamedb_pass;

$opts['db'] = Gamedb;

$opts['tb'] = 'votemodcat';



$opts['key'] = 'e';




$opts['key_type'] = 'int';




$opts['sort_field'] = array('id');







$opts['inc'] = 15;



// Options you wish to give the users
// A - add,  C - change, P - copy, V - view, D - delete,
// F - filter, I - initial sort suppressed


$opts['options'] = 'ACD';



// Number of lines to display on multiple selection filters


$opts['multiple'] = '4';



// Navigation style: B - buttons (default), T - text links, G - graphic links
// Buttons position: U - up, D - down (default)


$opts['navigation'] = 'DG';



// Display special page elements


$opts['display'] = array(
	'form'  => true,
	'query' => true,
	'sort'  => false,
	'time'  => false,
	'tabs'  => true
);



// Set default prefixes for variables


$opts['js']['prefix']               = 'PME_js_';
$opts['dhtml']['prefix']            = 'PME_dhtml_';

$opts['cgi']['prefix']['operation'] = 'PME_op_';

$opts['cgi']['prefix']['sys']       = 'PME_sys_';

$opts['cgi']['prefix']['data']      = 'PME_data_';



/* Get the user's default language and use it if possible or you can
   specify particular one you want to use. Refer to official documentation
   for list of available languages. */


$opts['language'] = 'EN-US';



$opts['fdd']['id'] = array(
  'name'     => 'ID',
  'select'   => 'T',
  'maxlen'   => 11,
  'sort'     => true
);
$opts['fdd']['category'] = array(
  'name'     => 'Category',
  'select'   => 'T',
  'maxlen'   => 65535,
  'textarea' => array(
    'rows' => 5,
    'cols' => 50),
  'sort'     => true
);
$opts['fdd']['e'] = array(
  'name'     => 'E',
  'select'   => 'T',
  'options'  => 'AVCPDR', // auto increment
  'maxlen'   => 11,
  'default'  => '0',
  'sort'     => true
);


// Now important call to phpMyEdit 


require_once 'phpMyEdit.class.php';
new phpMyEdit($opts);

?>

						
						<div id="article" style="min-height:0px;">
							<table style="margin-left:190px;">
								<tr>              
                                                                                                                                                                   <td>&bull;</td>
									<td><a href="../?act=admin">Back to Admin Panel</a></td>
									<td>&bull;</td>
                               
								</tr>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div id="page_footer">
			<div><div></div></div>
		</div>
	</div>
</body>
</html>


