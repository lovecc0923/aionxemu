<?php

if($_SESSION["access_level"] < 2)
{
	echo "<script>location.href='index.php'</script>";
	exit;
}


class Admin
{
	function Title()
	{
		?>
        	                                      Admin's page
        <?php
	}
 

function ListVoteModules9()
	{
		$Con = mysql_connect(Gamedb_host,Gamedb_user,Gamedb_pass);
		mysql_select_db(Gamedb);
		
		//clear expired vote timeouts
		mysql_query("DELETE FROM votes WHERE time < ".(time()-12*60*60));
		$res = mysql_query("SELECT id,name FROM votemodules WHERE id='9'");
		while($Row = mysql_fetch_array($res))
		{
			$r = mysql_query("SELECT time FROM votes WHERE module='9' AND ip='{$_SERVER['REMOTE_ADDR']}'");
			if(!$R = mysql_fetch_array($r))
				$time = "You can vote now!";
			else
			{
				$Expiretime = (int)$R['time'] + (12*60*60);
				$Until = $Expiretime - time();
				$time = ceil($Until/60/60);
			}
			if($time == 1)
				$time = $time." hour";
			elseif($time > 1)
				$time = $time." hours";
			?>				
				<tr>
					<td width="100px"><?php echo $Row['name']; ?></td>
					<td><b><?php echo $time; ?></b></td>
				</tr>
			<?php
		}
		mysql_close($Con);
	}
	
	function Main()
	{
		
		?></table>
				
							

<table style="font-size: 12px; color: rgb(255, 255, 255);" border="0" cellpadding="120" cellspacing="0" width="500">
 
  <td align="center">


<p><a href="admin/admin31.php"> -Category 1- </a></p>


<p><a href="admin/admin32.php">-Category 2 -</a></p>

<p><a href="admin/admin33.php">-Category 3 -</a></p>

<p><a href="admin/admin34.php">-Category 4-</a></p>

<p><a href="admin/admin35.php">-Category 5-</a></p>

<p><a href="admin/admin36.php">-Category 6-</a></p>

<p><a href="admin/admin37.php">-Category 7-</a></p>

<p><a href="admin/admin38.php">-Category 8-</a></p>

<p><a href="admin/admin39.php">-Category 9-</a></p>


           </table></table>
          
					
        <?php
	
	}
	
	function Content()
	{
		$this->Main();
	}

	function __construct()
	{
		include("html/main3.php");
	}
}




?>