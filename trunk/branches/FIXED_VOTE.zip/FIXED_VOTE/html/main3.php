<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php $this->Title(); ?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<!-- Prepare to enter... DIV HELL!!!! -->
<body>
	<div id="topBar"></div>
	<div id="page">
		<div id="page_header">
			<div><div></div></div>
		</div>
		<div id="page_content">
			<div id="page_content_wrapper">
				<div id="page_content_content">
					<div id="page_content_padding">
						<div id="header_bar">
							<div>
								<div><table style="margin-left:215px; height:38px; vertical-align:middle;"><tr><td><?php $this->Title(); ?></td></tr></table></span>								</div>
							</div>
						</div>
<table style="margin-left:110px;"><hr>
								<tr>              
                                                                                                                                                                   <td>&bull;</td>
									<td><a href="?">Vote</a></td>
									<td>&bull;</td>
                               
									
									<td><a href="?act=rewards">Redeem Points</a></td>

                                                                                                                                                                   <td>&bull;</td>
 
  
<td><a href="?act=chg_pwd">Change Pwd</a></td>
                                                                                                                                                                   <td>&bull;</td>
                                                                                                                                                                  <td><a href="?act=logout">Logout</a></td>
									<td>&bull;</td>
								</tr>
							</table>
<table style="margin-left:0px;" border="0" width="510"><hr>
				<tr>
					<td colspan="4">Account logged in: <strong><?php echo $_SESSION['account']; ?></strong>.<br>
					Total points: <b><?php echo $_SESSION['points']; ?></b><br>
					
					
				
			</table>
						<div id="article">
							<?php $this->Content(); ?>
						
					</div>
<?php
                                                                                                                                                      if($_SESSION["access_level"] > 2)
                                                                                                                                                {
	                                                                                                                                       ?>     
<table style="margin-left:215px;">
<td><a href="?act=admin">Admin Panel</a></td>
                                                                                                                                                                 
</tr>
							</table> <?php
	                                                                                                                                      
                                                                                                                                                                   }
                                                                                                                                                     ?>
				</div>
			</div>
		</div>
</div>


		<div id="page_footer">
			<div><div></div></div>
		</div>
	</div>
</body>
</html>
