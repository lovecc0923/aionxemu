<?php


define("Logindb_host","127.0.0.1");
define("Logindb_user","root");
define("Logindb_pass","PASSWORD");
define("Logindb","aengine_ls");

define("Gamedb_host","127.0.0.1");
define("Gamedb_user","root");
define("Gamedb_pass","PASSWORD");
define("Gamedb","aengine_gs");

$conn = @mysql_connect(Gamedb_host, Gamedb_user, Gamedb_pass) or die(mysql_error());

function __autoload($class_name){
    require_once $class_name . '.class.php';
}
//In game mail settings
define("MAIL_SUBJECT","Thanks For Voting!");
define("MAIL_BODY","Thank you for voting for Project X. Here is your reward!");

// Misc
define("RPPV1",5);
define("RPPV2",5);
define("RPPV3",5);
define("RPPV4",5);
define("RPPV5",5);
define("RPPV6",5);
define("RPPV7",5);
define("RPPV8",5);
define("RPPV9",5);


session_start();
// force login to view.
if(!$_SESSION['authenticated'] && $_GET['act'] != "vote")
{
	include("login.php");
	new Login();
	die;
}
switch($_GET['act'])
{
default:
	include("vote.php");
	new Vote();
	break;

case "chg_pwd":
	include("change_password.php");
	new Chg_pwd();
	break;
case "admin":
	include("admin.php");
	new Admin();
	break;
case "admin30":
	include("admin/admin30.php");
	new Admin();
	break;
case "install":
	include("index1.php");
	new Installer();
	break;
case "rewards":
	include("rewards.php");
	new Rewards();
	break;

case "rewards1":
	include("rewards/rewards1.php");
	new Rewards();
	break;
case "rewards2":
	include("rewards/rewards2.php");
	new Rewards();
	break;
case "rewards3":
	include("rewards/rewards3.php");
	new Rewards();
	break;
case "rewards4":
	include("rewards/rewards4.php");
	new Rewards();
	break;
case "rewards5":
	include("rewards/rewards5.php");
	new Rewards();
	break;
case "rewards6":
	include("rewards/rewards6.php");
	new Rewards();
	break;
case "rewards7":
	include("rewards/rewards7.php");
	new Rewards();
	break;
case "rewards8":
	include("rewards/rewards8.php");
	new Rewards();
	break;
case "rewards9":
	include("rewards/rewards9.php");
	new Rewards();
	break;
case "rewards10":
	include("rewards/rewards10.php");
	new Rewards();
	break;
case "spend1":
	include("spend/spend1.php");
	new Spend();
	break;
case "spend2":
	include("spend/spend2.php");
	new Spend();
	break;
case "spend3":
	include("spend/spend3.php");
	new Spend();
	break;
case "spend4":
	include("spend/spend4.php");
	new Spend();
	break;
case "spend5":
	include("spend/spend5.php");
	new Spend();
	break;
case "spend6":
	include("spend/spend6.php");
	new Spend();
	break;
case "spend7":
	include("spend/spend7.php");
	new Spend();
	break;
case "spend8":
	include("spend/spend8.php");
	new Spend();
	break;
case "spend9":
	include("spend/spend9.php");
	new Spend();
	break;
case "spend10":
	include("spend/spend10.php");
	new Spend();
	break;

case "logout":
	include("logout.php");
	new Logout();
	break;
case "chg_pwd":
	include("change_password.php");
	new chg_pwd();
	break;

}
?>
<?php include("footer.php");?>