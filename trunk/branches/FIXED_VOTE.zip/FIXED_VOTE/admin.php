<?php

if($_SESSION["access_level"] < 2)
{
	echo "<script>location.href='index.php'</script>";
	exit;
}


class Admin
{
	function Title()
	{
		?>
        	                                      Admin's page
        <?php
	}
 

function ListVoteModules9()
	{
		$Con = mysql_connect(Gamedb_host,Gamedb_user,Gamedb_pass);
		mysql_select_db(Gamedb);
		
		//clear expired vote timeouts
		mysql_query("DELETE FROM votes WHERE time < ".(time()-12*60*60));
		$res = mysql_query("SELECT id,name FROM votemodules WHERE id='9'");
		while($Row = mysql_fetch_array($res))
		{
			$r = mysql_query("SELECT time FROM votes WHERE module='9' AND ip='{$_SERVER['REMOTE_ADDR']}'");
			if(!$R = mysql_fetch_array($r))
				$time = "You can vote now!";
			else
			{
				$Expiretime = (int)$R['time'] + (12*60*60);
				$Until = $Expiretime - time();
				$time = ceil($Until/60/60);
			}
			if($time == 1)
				$time = $time." hour";
			elseif($time > 1)
				$time = $time." hours";
			?>				
				<tr>
					<td width="100px"><?php echo $Row['name']; ?></td>
					<td><b><?php echo $time; ?></b></td>
				</tr>
			<?php
		}
		mysql_close($Con);
	}
	
	function Main()
	{
		
		?></table>
				
							

<table style="font-size: 12px; color: rgb(255, 255, 255);" border="0" cellpadding="120" cellspacing="0" width="500">
 
  <td align="center">

<p><a href="admin/admin5.php"> -Manage Vote Links- </a></p>

<p><a href="admin/admin2.php"> -Edit Categories in Redeem Page- </a></p>


<p><a href="?act=admin30">-Edit Rewards-</a></p>
<p><a href="admin/admin3.php"> -Add/remove Vote Points- </a></p>




           </table></table>
          
					
        <?php
	
	}
	
	function Content()
	{
		$this->Main();
	}

	function __construct()
	{
		include("html/main3.php");
	}
}




?>